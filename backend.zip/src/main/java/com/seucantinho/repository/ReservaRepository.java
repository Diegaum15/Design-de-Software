// com.seucantinho.repository/ReservaRepository.java
package com.seucantinho.repository;

import com.seucantinho.model.Reserva;
import com.seucantinho.model.Espaco;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface ReservaRepository extends JpaRepository<Reserva, String> {

    // Método necessário pelo EspacoService
    @Query("SELECT r FROM Reserva r WHERE r.espaco = :espaco AND r.statusReserva IN ('PENDENTE', 'CONFIRMADA') AND " +
           "((r.dataEvento <= :dataFim AND r.dataEvento >= :dataInicio) OR " +
           " (r.dataEvento = :dataInicio))")
    List<Reserva> findReservasConflitantes(
        @Param("espaco") Espaco espaco, 
        @Param("dataInicio") LocalDateTime dataInicio, 
        @Param("dataFim") LocalDateTime dataFim
    );
    
    // Método necessário pelo ReservaService
    List<Reserva> findByClienteIdUsuario(String idCliente);
}