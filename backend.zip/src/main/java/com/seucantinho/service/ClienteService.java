package com.seucantinho.service;

import com.seucantinho.model.Cliente;
import com.seucantinho.repository.ClienteRepository;
import com.seucantinho.dto.ClienteDTO; 
import com.seucantinho.exception.ValidacaoException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional; // Importante para transações

import jakarta.persistence.EntityNotFoundException;
import java.util.List;
import java.util.Optional;

@Service
public class ClienteService {

    private final ClienteRepository clienteRepository;
    private final UsuarioService usuarioService;

    @Autowired
    public ClienteService(ClienteRepository clienteRepository, UsuarioService usuarioService) {
        this.clienteRepository = clienteRepository;
        this.usuarioService = usuarioService;
    }


    private Cliente toEntity(ClienteDTO dto) {
    // Usamos o SuperBuilder para construir o Cliente
    // O Cliente herda de Usuario, então podemos construir tudo aqui
        return Cliente.builder()
                .idUsuario(dto.getIdUsuario()) // Opcional, será nulo no registro
                .nome(dto.getNome())
                .email(dto.getEmail())
                .cpf(dto.getCpf())
                .senha(dto.getSenha())
                .telefone(dto.getTelefone())
                .endereco(dto.getEndereco())
                //.status(dto.getStatus()) // Se status estiver em Usuario
                .build();
    }

    // Local: com.seucantinho.service.ClienteService

    public ClienteDTO toDTO(Cliente cliente) {
        ClienteDTO dto = new ClienteDTO();
        dto.setIdUsuario(cliente.getIdUsuario());
        dto.setNome(cliente.getNome());
        dto.setEmail(cliente.getEmail());
        dto.setCpf(cliente.getCpf());
        dto.setTelefone(cliente.getTelefone());
        dto.setEndereco(cliente.getEndereco());
        
        // IMPORTANTE: NÃO RETORNAR A SENHA NO DTO DE SAÍDA!
        // dto.setSenha(cliente.getSenha()); // << Comente ou remova esta linha!
        
        return dto;
    }

    /**
     * Registra um novo Cliente no sistema.
     * @param cliente O objeto Cliente a ser salvo.
     * @return O Cliente registrado.
     */
    public ClienteDTO registrarCliente(ClienteDTO clienteDTO) {
        
        // 1. CONVERTE DTO -> ENTITY
        Cliente cliente = toEntity(clienteDTO); 

        // 2. Validação e Lógica de Negócio (O código existente permanece aqui)
        usuarioService.verificarEmailUnico(cliente.getEmail());
        
        if (cliente.getCpf() == null || cliente.getCpf().length() != 11) {
            throw new ValidacaoException("CPF inválido ou não fornecido.");
        }
        verificarCpfUnico(cliente.getCpf()); 

        // 3. Salva a Entity
        Cliente novoCliente = clienteRepository.save(cliente);

        // 4. CONVERTE ENTITY -> DTO E RETORNA
        return toDTO(novoCliente);
    }

    /**
     * Busca um Cliente pelo ID.
     * @param idCliente O ID do cliente.
     * @return O Cliente encontrado.
     * @throws EntityNotFoundException se o cliente não for encontrado.
     */
    public ClienteDTO buscarPorId(String idCliente) {
        // Busca a Entity
        Cliente cliente = clienteRepository.findById(idCliente)
                .orElseThrow(() -> new EntityNotFoundException("Cliente com ID " + idCliente + " não encontrado."));
        
        // Converte Entity -> DTO e retorna
        return toDTO(cliente);
    }

    public Cliente buscarEntityPorId(String idCliente) {
        return clienteRepository.findById(idCliente)
                .orElseThrow(() -> new EntityNotFoundException("Cliente com ID " + idCliente + " não encontrado."));
    }

        /**
     * Busca um Cliente pelo CPF.
     * @param cpf O CPF do cliente.
     * @return O Cliente encontrado.
     * @throws EntityNotFoundException se o cliente não for encontrado.
     */
    public ClienteDTO buscarPorCpf(String cpf) {
        Cliente cliente = clienteRepository.findByCpf(cpf);
        if (cliente == null) {
            throw new EntityNotFoundException("Cliente com CPF " + cpf + " não encontrado.");
        }
        return toDTO(cliente);
    }

    // Método para validar se o CPF é único (Mantido do código original)
    private void verificarCpfUnico(String cpf) {
        if (clienteRepository.findByCpf(cpf) != null) {
            throw new ValidacaoException("O CPF " + cpf + " já está cadastrado no sistema.");
        }
    }
    
    // Novo método para verificar email único no contexto de atualização
    private void verificarEmailUnicoAtualizacao(String novoEmail, String idAtual) {
        if (usuarioService.verificarEmailExistente(novoEmail) && 
            !idAtual.equals(usuarioService.buscarPorEmail(novoEmail).getIdUsuario())) {
            
            throw new ValidacaoException("O email " + novoEmail + " já está em uso por outro usuário.");
        }
    }

    /**
     * Atualiza os dados de um Cliente existente.
     * @param id O ID do cliente a ser atualizado.
     * @param clienteDetalhes Cliente com os dados a serem alterados.
     * @return Cliente atualizado.
     */
    @Transactional
    public ClienteDTO atualizarCliente(String id, ClienteDTO clienteDetalhesDTO) {
        Cliente clienteExistente = buscarEntityPorId(id); // Novo método auxiliar (veja abaixo)

        // 1. Validação de Email 
        if (!clienteExistente.getEmail().equals(clienteDetalhesDTO.getEmail())) {
            verificarEmailUnicoAtualizacao(clienteDetalhesDTO.getEmail(), id);
            clienteExistente.setEmail(clienteDetalhesDTO.getEmail());
        }

        // 2. Bloquear alteração de CPF
        if (!clienteExistente.getCpf().equals(clienteDetalhesDTO.getCpf())) {
            throw new ValidacaoException("A alteração do CPF (" + clienteExistente.getCpf() + ") não é permitida após o registro.");
        }

        // 3. Atualizar campos permitidos usando o DTO
        clienteExistente.setNome(clienteDetalhesDTO.getNome());
        clienteExistente.setTelefone(clienteDetalhesDTO.getTelefone());
        clienteExistente.setEndereco(clienteDetalhesDTO.getEndereco());
        
        // Atualização de Senha
        if (clienteDetalhesDTO.getSenha() != null && !clienteDetalhesDTO.getSenha().isEmpty()) {
            clienteExistente.setSenha(clienteDetalhesDTO.getSenha()); // Lembre-se de codificar isso
        }

        // Persiste e converte Entity -> DTO
        return toDTO(clienteRepository.save(clienteExistente));
    }
        
    /**
     * Deleta um Cliente pelo ID.
     * @param id O ID do cliente a ser deletado.
     * @throws EntityNotFoundException se o cliente não for encontrado.
     */
    @Transactional
    public void deletarCliente(String id) {
        Cliente cliente = buscarEntityPorId(id); // Usa o novo método interno
        clienteRepository.delete(cliente);
    }

    /**
     * Lista todos os Clientes.
     * @return Uma lista de todos os Clientes.
     */
    public List<ClienteDTO> listarTodos() {
        return clienteRepository.findAll().stream()
                .map(this::toDTO) // Mapeia cada Entity para um DTO
                .toList();
    }

}