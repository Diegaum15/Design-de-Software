package com.seucantinho.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "TB_SALAO")
@PrimaryKeyJoinColumn(name = "idEspaco")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class Salao extends Espaco {
    private String tamanhoCozinha;
    private int quantidadeCadeiras;
    private float areaTotal;
}